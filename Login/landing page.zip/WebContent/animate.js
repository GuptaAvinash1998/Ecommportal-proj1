$(document).ready(function(){
   $('col-sm-4').click(function(){
      $('col-sm-4').effect('SlideIn'); 
   });
});